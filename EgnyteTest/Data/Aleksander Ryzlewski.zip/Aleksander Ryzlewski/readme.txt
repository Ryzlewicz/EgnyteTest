This goal of this test is finishing several tasks based on our test platform. Person that undertakes the test will get a link to the proper website, on which all the tasks are to be performed. Functionality under test is sharing folders and files with different users. The tester gets such share link and is supposed to check whether it works correctly. The shared folder contains a combination of folders and files.
The shared link will be accessible by any person that has the password, but will expire after several days.

1. In about 20 minutes, perform exploratory tests on the functionality that can be found under the given link:
- Write a report what has been tested, and how has it been tested (No more than 20 sentences)
- Write whether any errors have been found

2. Write several test cases that you would use for regression testing:
- Write both positive and negative test cases
- Maximum 10 cases combined

3. Write an example defect report (if a defect has been found, then you can use it for the report)

4. Automate a few cases (minimum 5) from the test plan given in point 2 (at least one positive and at least one negative case).
Automation cannot be done using Record&Replay method (e.g. Selenium IDE, Ranorex, Sahi, etc)

Do you have any additional remarks?
